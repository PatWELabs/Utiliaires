// CreerReferentielGit.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <windows.h> 
#include <winhttp.h> 
#include <iostream> 
#include <string> 
#include <ShlObj_core.h>
#include <Shlwapi.h>
#pragma comment(lib, "winhttp.lib") 
#pragma comment(lib, "shlwapi.lib") 
int main()
{
	SetConsoleTitleA("CreerReferentielGit v:1.00");
	char path[MAX_PATH];
	char repo_name[40];// "nom_du_referentiel";
	BROWSEINFO bi = { 0 };
	bi.lpszTitle = L"Sélectionne le dossier à traiter";
	LPITEMIDLIST pidl = SHBrowseForFolder(&bi);
	if (pidl != 0) {
		if (SHGetPathFromIDListA(pidl, path))
		{
			std::cout << "Chemin: " << path << std::endl;
			strcpy_s(repo_name,PathFindFileNameA(path));
			std::cout << "Nom du referentiel extrait: " << repo_name << std::endl;
		}
		CoTaskMemFree(pidl);
	}
	else {
	return	MessageBox(GetDesktopWindow(),L"Aucun dossier choisi", L"CreerReferentielGit", MB_OK | MB_ICONERROR | MB_SYSTEMMODAL);
	}
	HINTERNET hSession = WinHttpOpen(L"A WinHTTP Example Program/1.0",
		WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
	if (hSession) 
	{ 
		HINTERNET hConnect = WinHttpConnect(hSession, L"api.github.com", INTERNET_DEFAULT_HTTPS_PORT, 0); 
		if (hConnect) 
		{ 
			HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", L"/user/repos", NULL, WINHTTP_NO_REFERER, 
				WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
			if (hRequest) { std::string token = ""; // Remplacez par votre token personnel GitHub 
			
			char json_data[80];
			sprintf_s(json_data, "{\"name\":\"%s\"}", repo_name);
			std::wstring headers = L"Content-Type: application/json\r\n"; 
			headers += L"Authorization: token " + std::wstring(token.begin(), token.end()) + L"\r\n"; 
			BOOL bResults = WinHttpSendRequest(hRequest, headers.c_str(), -1L, (LPVOID)json_data, strlen(json_data), strlen(json_data), 0); 
			if (bResults) { 
				bResults = WinHttpReceiveResponse(hRequest, NULL); 
			} 
			if (bResults) 
			{ 
				std::wcout << L"Référentiel créé avec succès !" << std::endl; 
			} else { 
				std::wcerr << L"Erreur lors de la création du référentiel." << std::endl; 
			}
			WinHttpCloseHandle(hRequest); 
			} 
			WinHttpCloseHandle(hConnect); 
		} 
		WinHttpCloseHandle(hSession); 
		char buffer[1024];
		sprintf_s(buffer, "echo \"# MDB_SQL_IMPORT\" >> README.md\ngit init\n \
		git add *.*\ngit commit -m \"%s\"git branch -M main\n \
		git remote add origin https://github.com/patdev-qc-ca/%s.git\ngit push -u origin main\n", repo_name, repo_name);
		system(buffer);
	} 
	return 0; 
}